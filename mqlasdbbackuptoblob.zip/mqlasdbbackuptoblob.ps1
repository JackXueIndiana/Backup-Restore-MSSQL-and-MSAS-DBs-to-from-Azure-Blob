Disable-AzureDataCollection
# Input parameters
$ServerName = "LOCALHOST"
$storageAccount ="jackxuesql3456"
$storageKey ="+Yksy1U7TFIT/SEBw8hSyE9OErCU59LQIX6gIfiqDkmlYxE67uItGKTZgf7GqfHl9fou1nigulQRYV2QNYsm+g=="
$container = "backups"

# Add the AMO namespace
$loadInfo = [System.Reflection.Assembly]::LoadWithPartialName(�Microsoft.AnalysisServices�) | Out-Null
[Microsoft.AnalysisServices.BackupInfo]$serverBackup = New-Object ([Microsoft.AnalysisServices.BackupInfo])
[Microsoft.AnalysisServices.Server]$server = New-Object Microsoft.AnalysisServices.Server
$server.connect($ServerName)
if ($server.name -eq $null) {
    Write-Output (�Server �{0}� not found� -f $ServerName)
    break
}

foreach ($db in $server.Databases)
{
    Write-Output(����������������������-�)
    Write-Output(�Server : {0}� -f $Server.Name)
    Write-Output(�Database: {0}� -f $db.Name)
    Write-Output(�DB State: {0}� -f $db.State)
    Write-Output(�DB Size : {0}� -f $db.EstimatedSize)
    Write-Output(����������������������-�)

    # Local backup preparation
    $BackupDestination=$server.ServerProperties.Item(�BackupDir�).value
    $serverBackup.AllowOverwrite = 1
    $serverBackup.ApplyCompression = 1
    $serverBackup.BackupRemotePartitions = 1
    if (-not $backupDestination.EndsWith(�\�)) {
        $backupDestination += �\�
    }

    [string]$backupTS = Get-Date -Format �yyyyMMddTHHmmss�
    $file= $db.name + �_� + $backupTS + �.abf�
    $serverBackup.file = $file

    # Local backup happens here
    $db.Backup($serverBackup)

    # If local backup success, then we do the Azure blob copy
    if ($?) {
        �Successfully backed up the analysis server workspace database � + $db.Name + � to � + $serverBackup.File

        #Copy the *.abf file to Azure blob
        $filepath = $BackupDestination + $file
        "Local backup path and file name: " + $filepath
        $context = New-AzureStorageContext -StorageAccountName $storageAccount -StorageAccountKey $storageKey
        Set-AzureStorageBlobContent -Blob $file -Container $container -File $filepath -Context $context -Force -BlobType Page
    } else {
        �Failed to back up � + $db.Name + � to � + $serverBackup.File
    }
}

#Always do this at the end
$server.Disconnect() 

